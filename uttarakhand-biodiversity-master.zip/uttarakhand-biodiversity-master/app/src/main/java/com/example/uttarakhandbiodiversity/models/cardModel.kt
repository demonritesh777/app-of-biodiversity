package com.example.uttarakhandbiodiversity.models

data class cardModel(
    var name : String,
    var descp : String,
    var image : String
)
